import SwiftUI
import Foundation
import AVFoundation

struct ContentView: View {
    
    
    
    @State var scrollAmount = 0.0

    @State var offset = CGSize.zero
    @State var audioPlayer: AVAudioPlayer?
    @State var isPlaying : Bool = false
    @State private var foo = Alphabet()

    
    
    var body: some View {
        
   
        
        VStack {
            
            
            ZStack(){
                
//                Stationary  black page
                
                Rectangle()
                    .frame(width: 720 , height: 800, alignment: .center)
                    .cornerRadius(10)
                    .offset(x: 0, y: -18)
                    .zIndex(-3)
    //    STATIONARY white page
                 Rectangle()
                        .frame(width: 680, height: 740)
                        .foregroundColor(.white)
                        .zIndex(-3)
            
                
                ZStack{
        
    //  ROTATING PAGES
        
                    Rectangle()
                        .frame(width: 680, height: 740)
                        .foregroundColor(.white)
                        .rotation3DEffect(.degrees(180), axis: (x: 1, y: 0, z: 0), anchor: .trailing)
                        .zIndex(0)
                
                }.rotation3DEffect(.degrees(scrollAmount), axis: (x: 1, y: 0, z: 0), anchor: .trailing)
                
                Image(foo.currentItem)
//                    .opacity(scrollAmount < 90 || scrollAmount >= 270 ? 1 : 0)
//                    .offset(x: 0, y: -40)
            
                
            }
            
            
            
            
//            Top Gesture
            .onTapGesture {
         newPage()
            }
//             dragGesture
            .gesture(
             DragGesture()
                .onChanged {
                    gesture in self.offset = gesture.translation
                }
                .onEnded { _ in
                    if self.offset.width > 0 {
                        newPage()
                        foo.next()
                
                    } else if self.offset.width < 0{
                        decrementAnimation()
                        foo.previous()
                    }
                    else{
                        self.offset = .zero
                    }
                })
            

            

            
            
            
            
            
            HStack(alignment: .center, spacing: 250) {
                Button("Previous") {
                
                    foo.previous()
                    decrementAnimation()
                        
                }
                
                .padding()
                
                
                
                
                Button("Music") {
                    
                    self.playsound(forResource: "Intro", ofType: ".mp3")
                    
               
                    
                }
                
                
 
           
                
                Button("Next") {
             
                    foo.next()
                    newPage()
                 
                        
                }.padding()
            }
        }
    }
    
    func newPage() {
        
        
        if  scrollAmount == 180 {
            withAnimation(.linear(duration: 0.15)){
                self.scrollAmount = 90
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2){
                withAnimation(.easeInOut(duration: 0.15)){
                   self.scrollAmount = 0
            }
        }

        } else if scrollAmount == 0 || scrollAmount == 360 {
            if scrollAmount == 0{
                
                self.scrollAmount = 360
            }
            withAnimation(.linear(duration: 0.15)) {
                self.scrollAmount -= 90
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2){
                withAnimation(.easeIn(duration: 0)){
                }
                withAnimation(.easeInOut(duration: 0.15)){
                    self.scrollAmount = 180
                }
            }
        }
}
    func decrementAnimation() {
            
 
        if scrollAmount == 180{
            withAnimation(.linear(duration: 0.15)) {
                self.scrollAmount = 180
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2){
          
                withAnimation(.easeInOut(duration: 0.15)){
              
                    self.scrollAmount = 360
                }
            }
        } else if scrollAmount == 0 || scrollAmount == 360 {
            if scrollAmount == 360{
                self.scrollAmount = 0
            }
            withAnimation(.linear(duration: 0.15)) {
                self.scrollAmount = 90
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2){
                withAnimation(.easeIn(duration: 0)){
          
                }

                withAnimation(.easeInOut(duration: 0.15)){
                    self.scrollAmount = 180
                }
            }
        }
    }

    
    
    
    
    
    
    
    
    private func playsound(forResource: String, ofType: String) {
        
        if let path = Bundle.main.path(forResource: forResource, ofType: ofType) {
            
            self.audioPlayer = AVAudioPlayer()
  
            let url = URL(fileURLWithPath: path)
            
            do {
                self.audioPlayer = try AVAudioPlayer(contentsOf: url)
                self.audioPlayer?.prepareToPlay()
                self.audioPlayer?.play()
            }catch {
                print("Error")
            }
        }
    }
}





extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        
        Group{
            Group{
                clipShape ( RoundedCorner(radius: radius, corners: corners))
            }
        }
    }
}

struct RoundedCorner : Shape {
  
    
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    
    func path(in rect: CGRect)-> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners , cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
        
    }
}


struct Alphabet {
    
    
    @State var scrollAmount = 0.0
    
    private let data : [String] = ["a-1",
                                  "a-2",
                                   "a-3",("a-4"),
                                   ("a-5"),
                                   ("a-6"),
                                   ("a-7"),
                                   ("a-8"),
                                   ("a-9"),
                                   ("a-10"),
                                   ("a-11"),
                                   ("a-12"),
                                  ("a-13"),
                                   ("a-14"),
                                  ("a-15"),
                                   ("a-16"),
                                   ("a-17"),
                                   ("a-18"),
                                   ("a-19"),
                                   ("a-20"),
                                   ("a-21"),
                                   ("a-22"),
                                   ("a-23"),
                                   ("a-24"),
                                   ("a-25"),
                                   ("a-26"),
                                   ("a-27"),
                                ("a-28"),
                                   ("a-29"),
                                   ("a-30"),
                                   ("a-31"),
                                   ("a-32"),
                                   ("a-33"),
                                   ("a-34"),
                                   ("a-35"),
                                   ("a-36"),
                                   ("a-37"),
                                   ("a-38"),
                                   ("a-39"),
                                   ("a-40"),
                                   ("a-41"),
                                ("a-42"),
                                   ("a-43"),
                                   ("a-44"),
                                   ("a-45"),
                                   ("a-46"),
                                   ("a-47"),
                                   ("a-48"),
                                   ("a-49"),
                                   ("a-50"),
                                   ("a-51"),
                                   ("a-52"),
                                   ("a-53"),
                                   ("a-54"),
                                   ("a-55"),
                                   ("a-56"),
                                   ("a-57"),
                                   ("a-58"),
                                   ("a-59"),
                                   ("a-60"),
                                   ("a-61"),
                                   ("a-62"),
                                   ("a-63"),
                                   ("a-64"),
                                   ("a-65"),
                                   ("a-66"),
                                   ("a-67"),
                                   ("a-68"),
                                   ("a-69"),
                                   ("a-70"),
                                   ("a-71"),
                                   ("a-72"),
                                   ("a-73"),
                                   ("a-74"),
                                   ("a-75"),
                                   ("a-76"),
                                   ("a-77"),
                                   ("a-78"),
                                   ("a-79"),
                                   ("a-80"),
                                   ("a-81"),
                                 ("a-82"),
                                   ("a-83"),
                                   ("a-84"),
                                   ("a-85"),
                                   ("a-86"),
                                   ("a-87"),
                                   ("a-88"),
                                   ("a-89"),
                                   ("a-90"),
                                   ("a-91"),
                                   ("a-92"),
                                   ("a-93"),
                                   ("a-94"),
                                   ("a-95"),
                                   ("a-96"),
                                   ("a-97"),
                                   ("a-98"),
                                   ("a-99"),
                                   ("a-100"),
                                   ("a-101"),
                                   ("a-102"),
                                   ("a-103"),
                                   ("a-104"),
                                   ("a-105"),
                                   ("a-106"),
                                   ("a-107"),
                                   ("a-108"),
                                   ("a-109"),
                                   ("a-110"),
                                   ("a-111"),
                                   ("a-112"),
                                   ("a-113"),
                                   ("a-114"),
                                   ("a-115"),
                                   ("a-116"),
                                   ("a-117"),
                                   ("a-118"),
                                   ("a-119"),
                                   ("a-120"),
                                   ("a-121"),
                                   ("c-1"),
                                   ("c-2"),
                                   ("c-3"),
                                   ("c-4"),
                                   ("c-5"),
                                   ("c-6"),
                                   ("c-7"),
                                   ("c-8"),
                                   ("c-9"),
                                   ("c-10"),
                                   ("c-11"),
                                   ("c-12"),
                                   ("c-13"),
                                   ("c-14"),
                                   ("c-15"),
                                   ("c-16"),
                                   ("c-17"),
                                   ("c-18"),
                                   ("c-19"),
                                   ("c-20"),
                                   ("c-21"),
                                   ("c-22"),
                                   ("c-23"),
                                   ("c-24"),
                                   ("c-25"),
                                   ("c-26"),
                                   ("c-27"),
                                   ("c-28"),
                                   ("c-29"),
                                   ("c-30"),
                                   ("c-31"),
                                   ("c-32"),
                                   ("c-33"),
                                   ("c-34"),
                                   ("c-35"),
                                   ("c-36"),
                                   ("c-37"),
                                   ("c-38"),
                                   ("c-39"),
                                   ("c-40"),
                                   ("c-41"),
                                   ("c-42"),
                                   ("d-1"),
                                   ("d-2"),
                                   ("d-3"),
                                   ("d-4"),
                                   ("d-5"),
                                   ("d-6"),
                                   ("d-7"),
                                   ("d-8"),
                                   ("d-9")]
    private var currentIndex: Int = 0
    private(set) var currentItem: String
    
    init() {
        currentItem = data[currentIndex]
    }
    
    mutating func next() {

        
        guard currentIndex < data.endIndex - 1 else { return }
        currentIndex += 1
        currentItem = data[currentIndex]

        
        
    }
        
      mutating  func previous() {
          

          
        guard currentIndex > data.startIndex else { return }
        currentIndex -= 1
        currentItem = data[currentIndex]
    }
}


